import numpy as np

array_var = np.array([1,2,3,4,5,6,7,8,9])
array_var = array_var.reshape((3,3))
print(array_var)