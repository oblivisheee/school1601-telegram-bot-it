from telebot import types

def start(message, bot):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn1 = types.KeyboardButton("📚 Уроки сегодня")
    btn2 = types.KeyboardButton("❓ Информация")
    markup.add(btn1, btn2)
    bot.send_message(message.chat.id, text="Привет, это бот с информацией нашего класса и других полезных вещей.", reply_markup=markup)

def info(message, bot):
    bot.send_message(message.chat.id, 'Привет, это пывп')

def lesson_day(message, bot, lesson_output):
    if message.text.lower() in ["📚 уроки сегодня", "уроки сегодня"]:
        today_schedule = lesson_output.get_today_schedule()
        if isinstance(today_schedule, list):
            if today_schedule:
                schedule_message = "Расписание на сегодня:\n"
                for lesson in today_schedule:
                    lesson_number = lesson.get('урок', 'Урок не найден').split()[-1]
                    lesson_name = lesson.get(f"урок {lesson_number}", 'Урок не найден')
                    schedule_message += f"Урок {lesson_number}: {lesson_name} ({lesson['время']})\n"
                bot.send_message(message.chat.id, schedule_message)
            else:
                bot.send_message(message.chat.id, "Уроки не были найдены.")
        else:
            bot.send_message(message.chat.id, "Уроки не были найдены или произошла ошибка. Обратитесь к администратору.")
