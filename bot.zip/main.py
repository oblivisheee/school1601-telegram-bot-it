import telebot
import config
import admin
from lesson import LessonOutput
import os
from telebot import types
from handlers import start, info, lesson_day

bot = telebot.TeleBot(config.BOT_TOKEN)

@bot.message_handler(commands=['start'])
def handle_start(message):
    start(message, bot)

@bot.message_handler(content_types=['text'])
def handle_text_message(message):
    if message.text == '❓ Информация':
        info(message, bot)
    elif message.text == '/admin_valid':
        if admin.admin_token_check(message.text):
            bot.send_message(message.chat.id, "Вы успешно вошли в аккаунт.")
        else:
            bot.send_message(message.chat.id, "Вы ввели неверный токен. Если вы не являетесь админом - перестаньте пытаться войти (вы всё равно ни к чему не придёте).")
            print(f"Someone with nickname {message.from_user.username} and ID: {message.from_user.id} is trying to log in as admin.\nStop them or help them if they are a real admin.\nLink to profile: https://t.me/{message.from_user.username}")

lesson_output = LessonOutput()

@bot.message_handler(content_types=['text'])
def handle_lessons(message):
    lesson_day(message, bot, lesson_output)

bot.polling(none_stop=True)
