import telebot
admin_usernames = {
    'oblivisheee': '1493358684',
    'Nikita Gennadyevich': '5752567293'
}

admin_tokens = {
    '9galhmt62bu4f90dn58s0n46vb35fds': 'oblivisheee',
    '7gf5hdfeuies602meu1nsf25pa91dfe': 'Nikita Gennadyevich'
}

def admin_token_check(input_token: str):
    if input_token in admin_tokens:
        print(f"Successfully logged in as admin, that was {admin_tokens[input_token]} with ID: {admin_usernames[admin_tokens[input_token]]}.\nLink to profile https://t.me/{admin_tokens[input_token]}")
        user_id = admin_tokens[input_token]
        return True and user_id
    else:
        print("")
    return False